function generateCommands() {
    let git_commands = {};
    try {
        /* Getting HTML Elements in a variable. */
        let release_element = document.getElementById("release");
        let tasktype_element = document.getElementById("tasktype");
        let taskno_element = document.getElementById("taskno");
        let owner_element = document.getElementById("owner");
        let cmtmsg_element = document.getElementById("cmtmsg");

        /* Storing values of the HTML elements in a variable */
        let release = (release_element) ? release_element.value : null;
        let tasktype = (tasktype_element) ? tasktype_element.value : null;
        let taskno = (taskno_element) ? taskno_element.value : null;
        let owner = (owner_element) ? owner_element.value : "Praveen";
        let cmtmsg = (cmtmsg_element) ? cmtmsg_element.value : null;

        /* Creating git commands that are independent of any inputs*/
        let pull = "git pull";
        let addall = "git add *";
        let gstatus = "git status";
        let reset_head = "git reset --hard HEAD^";

        /* Creating git commands that are dependent on Release no */
        let gswitch = (release) ? "git switch Release_CCSX" + release : null;
        let reset_origin = (release) ? "git reset --hard origin/Release_CCSX" + release : null;
        let push = (release) ? "git push origin Release_CCSX" + release + ":refs/for/Release_CCSX" + release : null;

        /* Creating Commit command. */
        let commitmsg = "";
        if (release && tasktype && taskno && owner && cmtmsg) {
            commitmsg = 'git commit -m "';

            /* Adding release details to commit msg */
            commitmsg = commitmsg + "Release:CCSX" + release;

            /* Adding task  details to commit msg */
            switch (tasktype) {
            case "JIRA":
                commitmsg = commitmsg + "|JIRA:" + taskno + "|QC:XXXX|CR:XXXX|INC:XXXX|";
                break;
            case "QC":
                commitmsg = commitmsg + "|JIRA:XXXX|QC:" + taskno + "|CR:XXXX|INC:XXXX|";
                break;
            case "CRM":
                commitmsg = commitmsg + "|JIRA:XXXX|QC:XXXX|CR:" + taskno + "|INC:XXXX|";
                break;
            case "INCIDENT":
                commitmsg = commitmsg + "|JIRA:XXXX|QC:XXXX|CR:XXXX|INC:" + taskno + "|";
                break;
            default:
                commitmsg = commitmsg + "|JIRA:XXXX|QC:XXXX|CR:XXXX|INC:XXXX|";
                break;
            }

            /* Adding Owner details to commit msg */
            commitmsg = commitmsg + "ACTION:Modified by " + owner + "|";

            /* Adding change details to commit msg */
            commitmsg = commitmsg + cmtmsg + '"';
        }

        /* Assigning all commands to one variable to return */
        git_commands["add"] = addall;
        git_commands["pull"] = pull;
        git_commands["push"] = push;
        git_commands["gswitch"] = gswitch;
        git_commands["gstatus"] = gstatus;
        git_commands["commitmsg"] = commitmsg;
        git_commands["reset_origin"] = reset_origin;
        git_commands["reset_head"] = reset_head;

    } catch (e) {
        console.log("Error Captured at generateCommands: " + e);
    }
    finally {}
    return git_commands;
}
function removeElementIfExists(id) {
    try {
        let elem = document.getElementById(id);
        if (elem) {
            elem.remove();
        }
    } catch (e) {
        console.log("Error at removeElementIfExists: " + e);
    }
    finally {}
}
function createButton(id, name, displayname, val, prntcntnr) {
    try {
        removeElementIfExists(id);
        let btn = document.createElement("button");
        btn.setAttribute("type", "submit");
        btn.setAttribute("id", id);
        btn.setAttribute("name", name);
        btn.innerHTML = displayname;
        btn.setAttribute("value", val);
        prntcntnr.insertAdjacentElement("beforeend", btn);
    } catch (e) {
        console.log("Error at createButton: " + e);
    }
    finally {}
}
function createGitButtons(git_commands) {
    try {
        let prntcntnr = document.getElementById("gt_bt_01");
        if (prntcntnr) {

            let gt_bt_st = "gt_bt_st";
            let gt_bt_oi = "gt_bt_oi";
            let gt_bt_pl = "gt_bt_pl";
            let gt_bt_ad = "gt_bt_ad";
            let gt_bt_cm = "gt_bt_cm";
            let gt_bt_ps = "gt_bt_ps";
            let gt_bt_fp = "gt_bt_fp";

            removeElementIfExists(gt_bt_st);
            removeElementIfExists(gt_bt_oi);
            removeElementIfExists(gt_bt_pl);
            removeElementIfExists(gt_bt_ad);
            removeElementIfExists(gt_bt_cm);
            removeElementIfExists(gt_bt_ps);
            removeElementIfExists(gt_bt_fp);

            if (git_commands["gswitch"]) {
                createButton(gt_bt_st, "gt_bt", "Switch", git_commands["gswitch"], prntcntnr);
            }
            if (git_commands["reset_origin"]) {
                createButton(gt_bt_oi, "gt_bt", "Reset Origin", git_commands["reset_origin"], prntcntnr);
            }
            if (git_commands["pull"]) {
                createButton(gt_bt_pl, "gt_bt", "Pull", git_commands["pull"], prntcntnr);
            }
            if (git_commands["add"]) {
                createButton(gt_bt_ad, "gt_bt", "Add all", git_commands["add"], prntcntnr);
            }
            if (git_commands["commitmsg"]) {
                createButton("gt_bt_cm", "gt_bt", "Commit", git_commands["commitmsg"], prntcntnr);
            }
            if (git_commands["push"]) {
                createButton("gt_bt_ps", "gt_bt", "Push", git_commands["push"], prntcntnr);
            }

            if (git_commands["add"] && git_commands["commitmsg"] && git_commands["push"]) {
                let force_push = git_commands["add"] + " && " + git_commands["commitmsg"] + " && " + git_commands["push"];
                createButton("gt_bt_fp", "gt_bt", "Force Push", force_push, prntcntnr);
            }
        }
    } catch (e) {
        console.log("Error at createGitButtons: " + e);
    }
    finally {}
}

function createGitButtonsWrapper() {
    try {
        let git_commands = generateCommands();
        createGitButtons(git_commands);
    } catch (e) {
        console.log("Error at createGitButtonsWrapper: " + e);
    }
    finally {}
}

/* Below scripts are expected to execute on load of the githome page */

createGitButtonsWrapper();
let release_element = document.getElementById("release");
let tasktype_element = document.getElementById("tasktype");
let taskno_element = document.getElementById("taskno");
let owner_element = document.getElementById("owner");
let cmtmsg_element = document.getElementById("cmtmsg");

document.addEventListener("click", (e) => {
	let alllistinps = document.getElementsByClassName("lst");
    for (let j = 0; j < alllistinps.length; j++) {
        if (alllistinps[j].classList.contains("display-none")) {}
		else{alllistinps[j].classList.add("display-none")}
    }
    if (e.target.classList.contains('lst-inp-txt-bx')) {
        let ul = e.target.nextElementSibling;
        if (ul) {
            if (ul.classList.contains("display-none")) {
                ul.classList.remove("display-none");
            }
        }
    }
    if(e.target.classList.contains("list-itms")){
		let val = e.target.innerHTML;
		let ul = e.target.parentElement;
		let inp = ul.previousElementSibling;
		inp.value = val;
	}
})
