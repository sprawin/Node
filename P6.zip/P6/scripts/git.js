module.exports = {
    runCommands: (inputs) => {
        try {
			let child_process = inputs['child_process'];
            let postmsg = inputs["postmsg"];
			let cmd = postmsg["gt_bt"];
			//let cmd = "dir";
			console.log("Executing command: "+cmd);
			child_process.exec(cmd,(err,output)=>{
				if(err){
					console.log("Error in execution of command: "+cmd);
					console.log(err);
				}else{
					console.log(output);
				}
			});
        } catch (e) {}
        finally {}
    }
};
