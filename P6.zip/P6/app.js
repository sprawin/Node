const express = require('express');
const bodyparser = require('body-parser');
const child_process = require('child_process');
const git = require('./scripts/git.js');

const app = express();

const port = 3000;

app.use(bodyparser.urlencoded({
        extended: true
    }));
app.use(express.static("public"));
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    res.render('githome', {
        "release": ["22.12", "23.1", "23.2", "23.3"],
        "tasktype": ["QC", "CRM", "RTB", "JIRA", "Incident", "Code Merge", "VFUKE"],
        "owner": ["Praveen", "RahulT", "ManjuR", "SaiVaishnavi", "RahulK", "Sadhana", "Swetha", "Ashish"]
    });
});

app.post('/', (req, res) => {
    let inputs = {
        "child_process": child_process,
        "postmsg": req.body
    };
    git.runCommands(inputs);
    res.render('githome', {
        "release": ["22.12", "23.1", "23.2", "23.3"],
        "tasktype": ["QC", "CRM", "RTB", "JIRA", "Incident", "Code Merge", "VFUKE"],
        "owner": ["Praveen", "RahulT", "ManjuR", "SaiVaishnavi", "RahulK", "Sadhana", "Swetha", "Ashish"]
    });
});

app.listen(port, () => {
    console.log("Server is up and running at port: " + port);
});
